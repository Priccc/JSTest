var content = document.getElementById('content');
var main = document.getElementById('main');
var ectable = document.getElementById('ectable');
var tds = ectable.getElementsByTagName('td');

var num1 = '';//第一个操作数
var num2 = '';//第二个操作数
var op = '';  //现在的操作数
var flag = 0; //检验第一个操作数是否存在
var temp = 0;

window.onresize = function(){
    content.style.width = document.documentElement.clientWidth + 'px';
    content.style.height = document.documentElement.clientHeight + 'px';
    main.style.cssText = 'top:50%;margin-top:-'+main.offsetHeight/2+'px;';
}
onresize();
function tempchange(){
    if(temp==1){
        temp =0;
    }
}
for(var i=0;i<tds.length;i++){
    tds[i].index = i;
    tds[i].addEventListener('click', function () {
        for(var i=0;i<tds.length;i++){
            if(i==0 || i==1){
                tds[i].className = 'red';
            }else{
                tds[i].className = '';
            }
        }
        tds[this.index].className = "this-td";

    });
    tds[i].addEventListener('click', function () {
        var str = this.innerHTML;
        var reg1 = /\d/g;
        var reg2 = /\+|\-|\*|\/|%/g;
        if(reg1.test(str)){// 数字0-9的点击事件

            if(temp ==1){
                num1 = '';
                con.innerHTML = '';
                temp = 0;
            }
            if(flag == 0){
                num1 += str;
                con.innerHTML = num1;
            }else {
                num2 += str;
                con.innerHTML = num2;
            }
        }else if(reg2.test(str)){//+，-，*，/，%的点击事件
            tempchange();
            if(num1 != '' && num2 != ''){
                num1 = eval(num1 + op + num2);
                num2 = '';
                con.innerHTML = num1;
            }
            flag = 1;
            op = str;
            //calculator()
        }else if(str == 'AC'){ //AC 清屏功能
            tempchange();
            flag=0;
            num1='';
            num2='';
            op='';
            temp = 0;
            con.innerHTML='';
        }else if(str == 'C'){  //C 退格功能
            tempchange();
            if(num2==''){
                num1 = con.innerHTML.substr(0,con.innerHTML.length-1);
                if(con.innerHTML.length-1 == 0){
                    num1 = '';
                }
                con.innerHTML = num1;
            }
            else{
                num2 = con.innerHTML.substr(0,con.innerHTML.length-1);
                if(con.innerHTML.length-1 == 0){
                    num2 = '';
                }
                con.innerHTML = num2;
            }
        }else if(str == '±'){ //正负值功能
            tempchange();
            if(num2==''){
                num1 = 0-num1;
                con.innerHTML = num1;
            }
            else{
                num2 = 0-num2;
                con.innerHTML = num2;
            }
        }else if(str == '='){ //=操作符功能
            tempchange();
            calculator(num1,num2,op);
        }else if(str == '.'){ //小数点功能
            tempchange();
            if(num2==''){
                num1 += str;
                con.innerHTML = num1;
            }
            else{
                num2 += str;
                con.innerHTML = num2;
            }
        }
    });
}
function calculator(x,y,o){
    x= parseFloat(x);
    if(y==''){
        num1 = x;
    }else{
        y= parseFloat(y);
        num1 = eval(x+o+y);
    }
    num2 = '';
    flag = 0;
    temp = 1;
    con.innerHTML = num1;
}
