var content = document.getElementById('content');
var add = document.getElementById('add');
var down = document.getElementById('down');
var strongnum = document.getElementById('p-button').getElementsByTagName('strong');
var divs = content.getElementsByTagName('div');
var num = 3,flag= true;
function creatediv(){
    content.innerHTML = '';
    for(var i=0;i<num;i++){
        for(var j=0;j<num;j++){
            var div = document.createElement('div');
            content.appendChild(div);
            if(j==0){
                div.style.clear = 'both';
            }
        }
    }
    content.style.width=div.offsetWidth*num+'px';
    strongnum[0].innerHTML = num;
    strongnum[1].innerHTML = num;
}
add.onclick = function () {
    num++;
    if(num>10) {
        alert('不能再增加难度了');
        num = 10;
    }
    creatediv();
    load();
}
down.onclick = function () {
    num--;
    if(num<2) {
        alert('不能再降低难度了');
        num = 2;
    }
    creatediv();
    load();
}
function load(){
    for(var i=0;i<num*num;i++){
        divs[i].index = i;
        divs[i].cflag = 0;
        divs[i].onclick = function () {
            var k = this.index;
            if(k<num){
                if(k==0){changecolor(k,null,k+1,k+num,null);}
                else if(k==num-1){changecolor(k,null,null,k+num,k-1);}
                else{changecolor(k,null,k+1,k+num,k-1);}
            }else if(k%num == 0){
                if(k == num*(num-1)){changecolor(k,k-num,k+1,null,null);}
                else{changecolor(k,k-num,k+1,k+num,null);}
            }else if((k+1)%num == 0){
                if(k==num*num-1){changecolor(k,k-num,null,null,k-1);}
                else{changecolor(k,k-num,null,k+num,k-1);}
            }else if(k>=(num*(num-1)) && k<num*num){
                changecolor(k,k-num,k+1,null,k-1);
            }else{
                changecolor(k,k-num,k+1,k+num,k-1);
            }
            var flag = checkgame();
            if(flag == true){
                alert('你赢了！');
                num++;
                creatediv();
                load();
            }
        }
    }
}

function changeone(x){
    if(divs[x].cflag == 0){
        divs[x].style.backgroundColor = '#a7d8dd';
        divs[x].cflag = 1;
    }
    else{
        divs[x].cflag = 0;
        divs[x].style.backgroundColor = '#eaebe6';

    }
}
function changecolor(a,b,c,d,e){
    if(a != null) changeone(a);
    if(b != null) changeone(b);
    if(c != null) changeone(c);
    if(d != null) changeone(d);
    if(e != null) changeone(e);

}
function checkgame(){
    flag = true;
    for(var i=0;i<num*num;i++){
        if(divs[i].cflag == 0){
            flag=false;
        }
    }
    return flag;
}
creatediv();
load();
